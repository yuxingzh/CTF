package main

import (
	"github.com/chainflag/eth-faucet/cmd"
)

func main() {
	cmd.Execute()
}
