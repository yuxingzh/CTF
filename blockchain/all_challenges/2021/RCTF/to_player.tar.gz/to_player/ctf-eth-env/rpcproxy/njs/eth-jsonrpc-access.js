function access(r) {
    var whitelist = [
        "net_version",
        "rpc_modules",
        "eth_chainId",
        "eth_getCode",
        "eth_getStorageAt",
        "eth_call",
        "eth_getTransactionReceipt",
        "eth_getTransactionCount",
        "eth_sendRawTransaction",
        "web3_clientVersion",
        "eth_estimateGas",
        "eth_gasPrice",
        "eth_blockNumber",
        "debug_traceTransaction"
    ];

    try {
        var payload = JSON.parse(r.requestBody);
        if (!whitelist.includes(payload.method)) {
            r.return(401, "jsonrpc method is not allow\n");
            return;
        }
    } catch (error) {
        r.return(415, "Cannot parse payload into JSON\n");
        return;
    }

    r.internalRedirect('@jsonrpc');
}

export default { access }